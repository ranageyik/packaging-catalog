export default fetch;
